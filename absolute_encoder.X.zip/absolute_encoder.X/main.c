#include <xc.h>
#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include "pic32_config.h"
#include "uart2.h"
#include "initialize.h"
#include "config.h"
#include "encoder.h"



int main(void)
{
    Init_SYS(NULL);

    uint32_t encoder1_value = 0;
    uint32_t encoder2_value = 0;
    
//    uint8_t ra_h, ra_m, ra_s;
//    uint16_t dec_deg;
//    uint8_t dec_m, dec_s;
    
    int8_t ra_h;
    uint8_t ra_m, ra_s;
    int16_t dec_d;
    uint8_t dec_m, dec_s;
        
    char msg[100];
    
    LED_1 = 1;

    while (1)
    {
//        encoder1_value = Read_17bit_Encoder(0);     // Read first encoder (using select 0,1,3)
//        encoder2_value = Read_17bit_Encoder(4);     // Read second encoder (assume wired to select 4,5,7)
//    
//        counts_to_ra_hms(encoder1_value, &ra_h, &ra_m, &ra_s);
//        counts_to_deg_dms(encoder2_value, &dec_deg, &dec_m, &dec_s);
//        
//        sprintf(msg, "RA  %+03dh %02dm %02ds\r\n", ra_h, ra_m, ra_s);
//        UART2_putStr(msg);
//
//        sprintf(msg, "DEC %+03d� %02d' %02d\"\r\n", dec_deg, dec_m, dec_s);
//        UART2_putStr(msg);
        
        
        uint32_t encoder1_counts = Read_17bit_Encoder(0); // RA
        uint32_t encoder2_counts = Read_17bit_Encoder(4); // DEC

        double ra_hours = EncoderToRA(encoder1_counts);
        double dec_degs = EncoderToDEC(encoder2_counts);


        RA_To_HMS(ra_hours, &ra_h, &ra_m, &ra_s);
        DEC_To_DMS(dec_degs, &dec_d, &dec_m, &dec_s);
        
        sprintf(msg, "RA  %03d:%02d:%02d\r\n", ra_h, ra_m, ra_s);
        UART2_putStr(msg);

        sprintf(msg, "DEC %03d� %02d' %02d\"\r\n", dec_d, dec_m, dec_s);
        UART2_putStr(msg);
        
        for (volatile int i = 0; i < 6000; i++);
    }

    return 0;
}