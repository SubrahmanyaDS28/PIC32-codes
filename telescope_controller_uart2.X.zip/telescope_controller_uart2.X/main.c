#include <sys/attribs.h>
#include "pic32_config.h"
#include "initialize.h"
#include "config.h"
#include "uart1.h"
#include "uart2.h"
#include "constants.h"
#include "extern.h"
#include "command.h"

char process_command(void);

FLAG COMMAND_RECEIVED;

unsigned char command[20];

unsigned int command_length = 0;

//unsigned int *load_buffer, *transfer_buffer;

unsigned int command_i;

int main() {
    unsigned int i, j;

    Init_SYS(NULL);

    UART2_putchar('~');
    UART2_putchar('~');
    UART2_putchar('~');

    LED_1 = !LED_1;
    LED_2 = !LED_2;
    LED_3 = !LED_3;
    
    

    
    while (1) {
        
        LED_3 = !LED_3;
//        if (uart_flag) {
//            uart_flag = 0;
//            process_command(uart_buffer);
//        }
        // other tasks...
        
        if (COMMAND_RECEIVED){
           UART2_putchar(process_command());
           COMMAND_RECEIVED = FALSE;
        }
        
        if(handset_enabled){
            LED_1 = 1;
            LED_2 = 0;
        }
        else{
            LED_1 = 0;
            LED_2 = 1;
        }
        
        for (i = 0; i < 2000; i++)
            for (j = 0; j < 2000; j++)
                Nop();
    }
}

char process_command(void) {
    unsigned int i = 0;
    char temp;
    
      switch (command[0]) {
            
        case 'Y':
            handset_enabled = 1;
            LED_1 = 1;
            LED_2 = 0;
            
            break;
             
        case 'X':
            handset_enabled = 0;
            LED_1 = 0;
            LED_2 = 1;
            break;
            
        // --- RA Commands ---
        case 'a':
            MOTOR_DIRECTION_RA = EAST_DIRECTION;
            TIMER_WEST_EAST = TIMER_VALUE(SLEW_FREQUENCY);
            RA_PULSE = PULSE_ON;
            DEC_PULSE = PULSE_OFF;   // ensure DEC is off
            break;

        case 'b':
            MOTOR_DIRECTION_RA = WEST_DIRECTION;
            TIMER_WEST_EAST = TIMER_VALUE(SLEW_FREQUENCY);
            RA_PULSE = PULSE_ON;
            DEC_PULSE = PULSE_OFF;
            break;

        case 'c':
            MOTOR_DIRECTION_RA = EAST_DIRECTION;
            TIMER_WEST_EAST = TIMER_VALUE(SET_FREQUENCY);
            RA_PULSE = PULSE_ON;
            DEC_PULSE = PULSE_OFF;
            break;

        case 'd':
            MOTOR_DIRECTION_RA = WEST_DIRECTION;
            TIMER_WEST_EAST = TIMER_VALUE(SET_FREQUENCY);
            RA_PULSE = PULSE_ON;
            DEC_PULSE = PULSE_OFF;
            break;

        case 'e':
            MOTOR_DIRECTION_RA = EAST_DIRECTION;
            TIMER_WEST_EAST = TIMER_VALUE(GUIDE_FREQUENCY);
            RA_PULSE = PULSE_ON;
            DEC_PULSE = PULSE_OFF;
            break;

        case 'f':
            MOTOR_DIRECTION_RA = WEST_DIRECTION;
            TIMER_WEST_EAST = TIMER_VALUE(GUIDE_FREQUENCY);
            RA_PULSE = PULSE_ON;
            DEC_PULSE = PULSE_OFF;
            break;

        case 'g':
            MOTOR_DIRECTION_RA = EAST_DIRECTION;
            TIMER_WEST_EAST = TIMER_VALUE(FINE_GUIDE_FREQUENCY);
            RA_PULSE = PULSE_ON;
            DEC_PULSE = PULSE_OFF;
            break;

        case 'h':
            MOTOR_DIRECTION_RA = WEST_DIRECTION;
            TIMER_WEST_EAST = TIMER_VALUE(FINE_GUIDE_FREQUENCY);
            RA_PULSE = PULSE_ON;
            DEC_PULSE = PULSE_OFF;
            break;

        // --- DEC Commands ---
        case 'A':
            
            LED_2 = 0;
            MOTOR_DIRECTION_DEC = NORTH_DIRECTION;
            TIMER_NORTH_SOUTH = TIMER_VALUE(SLEW_FREQUENCY);
            DEC_PULSE = PULSE_ON;
            RA_PULSE = PULSE_OFF;   // ensure RA is off
            break;

        case 'B':
            MOTOR_DIRECTION_DEC = SOUTH_DIRECTION;
            TIMER_NORTH_SOUTH = TIMER_VALUE(SLEW_FREQUENCY);
            DEC_PULSE = PULSE_ON;
            RA_PULSE = PULSE_OFF;
            break;

        case 'C':
            MOTOR_DIRECTION_DEC = NORTH_DIRECTION;
            TIMER_NORTH_SOUTH = TIMER_VALUE(SET_FREQUENCY);
            DEC_PULSE = PULSE_ON;
            RA_PULSE = PULSE_OFF;
            break;

        case 'D':
            MOTOR_DIRECTION_DEC = SOUTH_DIRECTION;
            TIMER_NORTH_SOUTH = TIMER_VALUE(SET_FREQUENCY);
            DEC_PULSE = PULSE_ON;
            RA_PULSE = PULSE_OFF;
            break;

        case 'E':
            MOTOR_DIRECTION_DEC = NORTH_DIRECTION;
            TIMER_NORTH_SOUTH = TIMER_VALUE(GUIDE_FREQUENCY);
            DEC_PULSE = PULSE_ON;
            RA_PULSE = PULSE_OFF;
            break;

        case 'F':
            MOTOR_DIRECTION_DEC = SOUTH_DIRECTION;
            TIMER_NORTH_SOUTH = TIMER_VALUE(GUIDE_FREQUENCY);
            DEC_PULSE = PULSE_ON;
            RA_PULSE = PULSE_OFF;
            break;

        case 'G':
            MOTOR_DIRECTION_DEC = NORTH_DIRECTION;
            TIMER_NORTH_SOUTH = TIMER_VALUE(FINE_GUIDE_FREQUENCY);
            DEC_PULSE = PULSE_ON;
            RA_PULSE = PULSE_OFF;
            break;

        case 'H':
            MOTOR_DIRECTION_DEC = SOUTH_DIRECTION;
            TIMER_NORTH_SOUTH = TIMER_VALUE(FINE_GUIDE_FREQUENCY);
            DEC_PULSE = PULSE_ON;
            RA_PULSE = PULSE_OFF;
            break;

        // --- No valid command ---
          case 's':
            RA_PULSE = PULSE_OFF;
            DEC_PULSE = PULSE_OFF;
            handset_enabled = 0;
            break;
//        case CMD_NONE:
//        default:
//            RA_PULSE = PULSE_OFF;
//            DEC_PULSE = PULSE_OFF;
//            handset_enabled = 0;
//            break;
      }
      return ACK;
    }

