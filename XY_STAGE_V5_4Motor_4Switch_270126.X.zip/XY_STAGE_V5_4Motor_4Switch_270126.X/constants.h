#ifndef __CONSTANTS_H__
    #define __CONSTANTS_H__

    #define INPUT   1
    #define OUTPUT  0
    #define START	1
    #define STOP	0
    #define TRUE    1
    #define FALSE   0
    #define STx	    '*'
    #define ETx	    '#'
    #define NAK	    '!'
    #define ACK	    '^'
//    #define HIGH     1
//    #define LOW      0
//    #define ON      1
//    #define OFF     0 



#endif